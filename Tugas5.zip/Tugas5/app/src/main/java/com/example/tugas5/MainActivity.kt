package com.example.tugas5

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etJam: EditText
    private lateinit var etTanggal: EditText
    private lateinit var btnJam: ImageButton
    private lateinit var btnTanggal: ImageButton
    private lateinit var btnToast: Button // Tambahkan ini

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etJam = findViewById(R.id.etJam)
        etTanggal = findViewById(R.id.etTanggal)
        btnJam = findViewById(R.id.btnJam)
        btnTanggal = findViewById(R.id.btnTanggal)
        btnToast = findViewById(R.id.btnToast) // Hubungkan tombolnya

        btnJam.setOnClickListener {
            tampilkanTimePicker()
        }

        etJam.setOnClickListener {
            tampilkanTimePicker()
        }

        btnTanggal.setOnClickListener {
            tampilkanDatePicker()
        }

        etTanggal.setOnClickListener {
            tampilkanDatePicker()
        }

        // Tampilkan Toast saat tombol ditekan
        btnToast.setOnClickListener {
            Toast.makeText(this, "Ini adalah Toast Android Native!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun tampilkanTimePicker() {
        val kalender = Calendar.getInstance()
        val jam = kalender.get(Calendar.HOUR_OF_DAY)
        val menit = kalender.get(Calendar.MINUTE)

        val dialog = TimePickerDialog(this, { _: TimePicker, hourOfDay: Int, minute: Int ->
            val periode = if (hourOfDay < 12) "AM" else "PM"
            val jamTampil = if (hourOfDay == 0 || hourOfDay == 12) 12 else hourOfDay % 12
            val waktu = String.format(Locale.getDefault(), "%02d:%02d %s", jamTampil, minute, periode)
            etJam.setText(waktu)
            Toast.makeText(this, "Jam dipilih: $waktu", Toast.LENGTH_SHORT).show()
        }, jam, menit, false)

        dialog.show()
    }

    private fun tampilkanDatePicker() {
        val kalender = Calendar.getInstance()
        val tahun = kalender.get(Calendar.YEAR)
        val bulan = kalender.get(Calendar.MONTH)
        val tanggal = kalender.get(Calendar.DAY_OF_MONTH)

        val dialog = DatePickerDialog(this, { _: DatePicker, year: Int, month: Int, dayOfMonth: Int ->
            val bulanFix = month + 1
            val tanggalLengkap = String.format(Locale.getDefault(), "%02d-%02d-%04d", dayOfMonth, bulanFix, year)
            etTanggal.setText(tanggalLengkap)
            Toast.makeText(this, "Tanggal dipilih: $tanggalLengkap", Toast.LENGTH_SHORT).show()
        }, tahun, bulan, tanggal)

        dialog.show()
    }
}
